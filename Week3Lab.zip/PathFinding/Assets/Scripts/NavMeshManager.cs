// KHOGDEN 001115381
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NavMeshManager : MonoBehaviour
{
    public static NavMeshManager instance;
    private List<Transform> destinations = new List<Transform>();

    // Called before 'void Start()'.
    private void Awake()
    {
        instance = this;

        for(int i = 0; i < transform.childCount; i++)
            destinations.Add(transform.GetChild(i).transform);
    }

    // Method to get a destination transform from 'destinations'.
    public Transform GetDestination(int index)
    {
        return destinations[index];
    }

    // Method to get a random destination transform from the 'destinations' array.
    public Transform GetRandomDestination()
    {
        return destinations[Random.Range(0, destinations.Count)];
    }
}
