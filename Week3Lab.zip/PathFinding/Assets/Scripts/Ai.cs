// KHOGDEN 001115381
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Ai : MonoBehaviour
{
    // The radius for how far the AI must be to it's destination to have 'reached' it.
    [SerializeField][Range(0.001f, 1f)] float reachRadius = 0.1f;
    [SerializeField] Material[] materials = new Material[0];

    private NavMeshAgent agent;
    private MeshRenderer render;

    // Called before 'void Start()'.
    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        render = GetComponentInChildren<MeshRenderer>();
    }

    // Called upon first frame.
    private void Start()
    {
        SetRandomMaterial();
    }

    // Update is called once per frame
    void Update()
    {
        // If the AI is in reached radius of it's destination, set it a new destination.
        if(agent.remainingDistance < reachRadius)
            SetDestination(NavMeshManager.instance.GetRandomDestination());
    }

    // Set a new destination for the AI to focus travelling to.
    void SetDestination(Transform pos)
    {
        agent.SetDestination(pos.position);
    }

    // Set a random material for this NPC out of the 'materials' list.
    void SetRandomMaterial()
    {
        render.material = materials[Random.Range(0, materials.Length)];
    }
}
