// KHOGDEN 001115381
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace level
{
    public class InteractiveTile : MonoBehaviour
    {
        // Initialise the interactive tile.
        virtual public void Initialize()
        {

        }
    }
}