// KHOGDEN 001115381
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplyMaterial : MonoBehaviour
{
    // Small script I made to apply materials to terrain without editing lab files!
    [SerializeField] Material mat;
    private Renderer render;

    // Called before 'void Start()'.
    private void Awake()
    {
        render = GetComponent<Renderer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        render.material = mat;
    }
}
