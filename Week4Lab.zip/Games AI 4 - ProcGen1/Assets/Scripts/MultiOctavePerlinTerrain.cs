using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[ExecuteInEditMode]
[Serializable]
public class Octave
{
    public bool enabled = true;
    public int seed = 0;
    public float noiseScale = 1.0f;
    public float effectScale = 1.0f;
}

public class MultiOctavePerlinTerrain : MonoBehaviour
{
    private Mesh mesh;
    private Vector3[] vertices;
    private int[] triangles;

    public int xSize = 20;
    public int zSize = 20;
    public float heightMultiplier = 3.0f;

    public Octave[] octaves;

    // Variables to store previous state
    private Octave[] prevOctaves;
    private int prevXSize, prevZSize;
    private float prevHeightMultiplier;

    void Start()
    {
        mesh = new Mesh();
        GetComponent<MeshFilter>().mesh = mesh; // Make sure your GameObject has a MeshFilter component attached
        InitializeDefaults();
        CreateShape();
        UpdateMesh();
    }


    void Update()
    {
        // Check if any value has changed
        if (HasChanged())
        {
            CreateShape();
            UpdateMesh();
            UpdatePreviousState();
        }
    }

    void InitializeDefaults()
    {
        if (octaves == null || octaves.Length == 0)
        {
            octaves = new Octave[1];
            octaves[0] = new Octave
            {
                enabled = true,
                seed = 0,
                noiseScale = 1.0f,
                effectScale = 1.0f
            };
        }
    }

    bool HasChanged()
    {
        if (prevXSize != xSize || prevZSize != zSize || prevHeightMultiplier != heightMultiplier)
            return true;

        if (prevOctaves == null || octaves.Length != prevOctaves.Length)
            return true;

        for (int i = 0; i < octaves.Length; i++)
        {
            if (octaves[i].enabled != prevOctaves[i].enabled ||
                octaves[i].seed != prevOctaves[i].seed ||
                octaves[i].noiseScale != prevOctaves[i].noiseScale ||
                octaves[i].effectScale != prevOctaves[i].effectScale)
            {
                return true;
            }
        }

        return false;
    }

    void UpdatePreviousState()
    {
        prevXSize = xSize;
        prevZSize = zSize;
        prevHeightMultiplier = heightMultiplier;
        prevOctaves = (Octave[])octaves.Clone();
    }

    void CreateShape()
    {
        vertices = new Vector3[(xSize + 1) * (zSize + 1)];
        triangles = new int[xSize * zSize * 6];

        for (int i = 0, z = 0; z <= zSize; z++)
        {
            for (int x = 0; x <= xSize; x++)
            {
                float y = 0f;

                foreach (Octave octave in octaves)
                {
                    if (!octave.enabled)
                        continue;

                    float xOffset = octave.seed * 1000;
                    float zOffset = (octave.seed + 1) * 1000;

                    y += Mathf.PerlinNoise((x + xOffset) * octave.noiseScale, (z + zOffset) * octave.noiseScale) * octave.effectScale;
                }

                y *= heightMultiplier;
                vertices[i] = new Vector3(x, y, z);
                i++;
            }
        }

        int vert = 0;
        int tris = 0;
        for (int z = 0; z < zSize; z++)
        {
            for (int x = 0; x < xSize; x++)
            {
                triangles[tris] = vert;
                triangles[tris + 1] = vert + xSize + 1;
                triangles[tris + 2] = vert + 1;
                triangles[tris + 3] = vert + 1;
                triangles[tris + 4] = vert + xSize + 1;
                triangles[tris + 5] = vert + xSize + 2;

                vert++;
                tris += 6;
            }
            vert++;
        }
    }

    void UpdateMesh()
    {
        mesh.Clear();
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();
    }
}
