using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeamlessNoiseLooper : MonoBehaviour
{
    [Header("Noise Parameters")]
    public float noiseScale = 0.1f;
    public float loopDuration = 10f;  // Duration of the loop in seconds

    private float seed;  // Random seed for the noise loop
    private float time;  // Elapsed time since the start of the loop

    // Start is called before the first frame update
    void Start()
    {
        // Initialize the random seed and time
        seed = Random.Range(0f, 1000f);
        time = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        // Update the elapsed time
        time += Time.deltaTime;

        // Generate the seamless noise value
        float noiseValue = GetSeamlessNoise();

        // Use the noise value to change the rotation, or any other property.
        // For example, change the y-axis rotation using the noise value:
        transform.Rotate(0, noiseValue, 0);
    }

    /// <summary>
    /// Generates a seamless loop of Perlin noise by sampling along a circular path.
    /// </summary>
    /// <returns>A value from the Perlin noise function.</returns>
    private float GetSeamlessNoise()
    {
        // Normalize time to [0, 1] for one complete loop
        float normalizedTime = time % loopDuration / loopDuration;

        // Calculate angle corresponding to time, ranging from 0 to 2*PI
        float angle = normalizedTime * 2 * Mathf.PI;

        // Calculate circular coordinates (x, y) based on angle and seed
        float x = Mathf.Cos(angle) + seed;
        float y = Mathf.Sin(angle) + seed;

        // Sample Perlin noise using circular coordinates
        float noiseValue = Mathf.PerlinNoise(x * noiseScale, y * noiseScale);

        // Adjust the noise value to be between -1 and 1
        return (noiseValue * 2) - 1;
    }
}
