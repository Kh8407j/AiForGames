using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlySpaceController : MonoBehaviour
{
    public float orbit;  // Orbit distance for the Fly GameObject

    private float xRotationRate;
    private float yRotationRate;
    private float zRotationRate;

    void Start()
    {
        // Initialize random rotation rates in degrees per second
        xRotationRate = Random.Range(36, 180);  // 0.1 to 0.5 revolutions per second
        yRotationRate = Random.Range(36, 180);
        zRotationRate = Random.Range(36, 180);

        // Set random initial rotation for the FlySpace object
        float randomX = Random.Range(0, 360);
        float randomY = Random.Range(0, 360);
        float randomZ = Random.Range(0, 360);
        transform.rotation = Quaternion.Euler(randomX, randomY, randomZ);

        // Create Fly GameObject
        GameObject fly = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fly.name = "Fly";
        fly.transform.SetParent(transform);

        // Position the Fly based on the orbit parameter
        fly.transform.localPosition = new Vector3(orbit, 0, 0);

        // Optional: scale down the Fly GameObject for visibility
        fly.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
    }

    void Update()
    {
        // Rotate the FlySpace object based on the rotation rates
        transform.Rotate(xRotationRate * Time.deltaTime, yRotationRate * Time.deltaTime, zRotationRate * Time.deltaTime);
    }

    // This function is called to draw gizmos in the editor
    void OnDrawGizmos()
    {
        // Set the gizmo color
        Gizmos.color = Color.green;

        int numSegments = 50;  // Number of segments to draw the circle
        Vector3 prevPos = transform.position + transform.right * orbit;  // Start point of the circle

        for (int i = 1; i <= numSegments; i++)
        {
            // Calculate the angle for this segment
            float angle = i * 360f / numSegments;
            Quaternion rotation = Quaternion.AngleAxis(angle, transform.forward);

            // Calculate the position for this segment
            Vector3 newPos = transform.position + rotation * transform.right * orbit;

            // Draw a line between the previous and current segment positions
            Gizmos.DrawLine(prevPos, newPos);

            // Update prevPos for the next iteration
            prevPos = newPos;
        }
    }

}
