using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwarmController : MonoBehaviour
{
    [Header("Swarm Parameters")]
    public int numFlySpaces = 10;  // Number of FlySpace objects
    public GameObject flyPrefab;  // The Fly GameObject
    public float swarmYRotationSpeed = 30f; // Y-axis rotation speed for all FlySpaces

    // Start is called before the first frame update
    void Start()
    {
        // Generate FlySpace objects and their children (Fly)
        for (int i = 0; i < numFlySpaces; i++)
        {
            // Create a new GameObject for FlySpace
            GameObject flySpace = new GameObject("FlySpace" + i);
            flySpace.transform.parent = this.transform;  // Set Swarm as parent
            flySpace.transform.localPosition = Vector3.zero;  // Position at the parent's origin
            
            // Attach the SeamlessNoiseLooper script and initialize its variables
            SeamlessNoiseLooper noiseLooper = flySpace.AddComponent<SeamlessNoiseLooper>();
            noiseLooper.noiseScale = Random.Range(0.1f, 0.5f);
            noiseLooper.loopDuration = Random.Range(5f, 15f);
            
            // Set the FlySpace's initial rotation
            float xRotation = Random.Range(0f, 360f);
            float yRotation = Random.Range(0f, 360f);
            float zRotation = Random.Range(0f, 360f);
            flySpace.transform.localRotation = Quaternion.Euler(xRotation, yRotation, zRotation);

            // Create and position the Fly object
            GameObject fly = Instantiate(flyPrefab, flySpace.transform);
            float orbitDistance = Random.Range(1f, 5f);  // Set orbit distance
            fly.transform.localPosition = new Vector3(orbitDistance, 0, 0);  // Position the Fly object
            
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Rotate all FlySpace objects around the y-axis at the same rate
        foreach (Transform child in transform)
        {
            child.Rotate(0, swarmYRotationSpeed * Time.deltaTime, 0);
        }
    }

}
